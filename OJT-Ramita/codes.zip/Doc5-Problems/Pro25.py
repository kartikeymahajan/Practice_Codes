'''25.Write a function that employs regular expressions to ensure the password given to 
the function is strong. A strong password is defined as follows:
-at least eight characters long
-contains one uppercase character
-contains one lowercase character
-has at least one digit
-has at least one special character'''
