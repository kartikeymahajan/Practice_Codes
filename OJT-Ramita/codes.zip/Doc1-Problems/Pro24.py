'''24. You have given a string str1 = 'abcbaefabcabchijkl'
your task is to find the combination of given word without repetition, present in the
string , given
word &#39;abc&#39;
o/p = 7
explaination :
abc, cba,
cba,
bca, acb
cab, bac '''