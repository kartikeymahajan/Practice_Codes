from add_sub import *
from mul_div import *

print("addition =",addition(5,2))
print("subtraction =", subtraction(5,2))
print("multiplicatoin =", multiplication(5,2))
print("division =", division(5,2))