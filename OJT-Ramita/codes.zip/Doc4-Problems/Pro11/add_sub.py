
def addition(f_value, *args):
    for i in args:
        f_value += i
    return f_value

def subtraction(f_value, *args):
    for i in args:
        f_value -= i 
    return f_value
