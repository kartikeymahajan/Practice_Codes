'''16.Let's consider there are two files, one file contains testnames, other file 
contains testnames and status for each one. Generate dictionary with key's as testname 
and value as status

Input:

File1.txt:

test1 test2
File2.txt:

test1-pass test2-fail
Output :

{ "test1" : "pass", "test2" : "fail"}'''