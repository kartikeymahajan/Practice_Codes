'''28. Standardize mobile numbers when given N mobile numbers. Sort them in
ascending order. Print them in the standard format.'''