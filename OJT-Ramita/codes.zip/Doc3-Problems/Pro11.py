'''11. Rewrite the program to get proper output
Match = "version"
input=8
print(Match+input)'''

Match = "version"
input=8
print(Match+str(input))

