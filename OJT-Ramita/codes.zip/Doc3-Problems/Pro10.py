'''10. Write the output of the program:
match = 'version', input='Upgraded_image_version_8.0.4.3'
if match in input:
print('YES')
else:
print('NO')'''

